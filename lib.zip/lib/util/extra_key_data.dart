import 'package:flutter/material.dart';
import 'package:flutter_studio/util/extra_key_model.dart';

// Keys for the first row of extra keys
const List<ExtraKey> extraKeysRow1Data = [
  ExtraKey(label: 'Ctrl', action: ExtraKeyAction.modifier, value: 'ctrl'),
  ExtraKey(label: 'Shift', action: ExtraKeyAction.modifier, value: 'shift'),
  ExtraKey(label: 'Alt', action: ExtraKeyAction.modifier, value: 'alt'),
  ExtraKey(label: 'Tab', action: ExtraKeyAction.insert, value: '\t'),
  ExtraKey(label: 'ESC', action: ExtraKeyAction.command, value: 'dismissSuggestions'), // Custom command to dismiss LSP suggestions
  ExtraKey(label: 'Action', action: ExtraKeyAction.command, value: 'getCodeAction'),
  ExtraKey(label: 'SIGN', action: ExtraKeyAction.command, value: 'callSignatureHelp'),
  ExtraKey(label: '{', action: ExtraKeyAction.insert, value: '{'),
  ExtraKey(label: '}', action: ExtraKeyAction.insert, value: '}'),
  ExtraKey(label: '[', action: ExtraKeyAction.insert, value: '['),
  ExtraKey(label: ']', action: ExtraKeyAction.insert, value: ']'),
  ExtraKey(label: '(', action: ExtraKeyAction.insert, value: '('),
  ExtraKey(label: ')', action: ExtraKeyAction.insert, value: ')'),
  ExtraKey(label: '<', action: ExtraKeyAction.insert, value: '<'),
  ExtraKey(label: '>', action: ExtraKeyAction.insert, value: '>'),
];

// Keys for the second row of extra keys
const List<ExtraKey> extraKeysRow2Data = [
  ExtraKey(icon: Icons.arrow_left, action: ExtraKeyAction.arrow, value: 'left'),
  ExtraKey(icon: Icons.arrow_right, action: ExtraKeyAction.arrow, value: 'right'),
  ExtraKey(icon: Icons.arrow_upward, action: ExtraKeyAction.arrow, value: 'up'),
  ExtraKey(icon: Icons.arrow_downward, action: ExtraKeyAction.arrow, value: 'down'),
  ExtraKey(label: 'Dup', action: ExtraKeyAction.command, value: 'duplicateLine'),
  ExtraKey(label: 'Back', action: ExtraKeyAction.backspace), // Explicit backspace
  ExtraKey(label: 'Del', action: ExtraKeyAction.delete),     // Explicit delete
  ExtraKey(label: ';', action: ExtraKeyAction.insert, value: ';'),
  ExtraKey(label: "'", action: ExtraKeyAction.insert, value: "'"),
  ExtraKey(label: '"', action: ExtraKeyAction.insert, value: '"'),
  ExtraKey(label: '&', action: ExtraKeyAction.insert, value: '&'),
  ExtraKey(label: '|', action: ExtraKeyAction.insert, value: '|'),
  ExtraKey(label: '=', action: ExtraKeyAction.insert, value: '='),
  ExtraKey(label: '/', action: ExtraKeyAction.insert, value: '/'),
  ExtraKey(label: '!', action: ExtraKeyAction.insert, value: '!'),
  ExtraKey(label: '?', action: ExtraKeyAction.insert, value: '?'),
  ExtraKey(label: '~', action: ExtraKeyAction.insert, value: '~'),
  ExtraKey(label: '`', action: ExtraKeyAction.insert, value: '`'),
  ExtraKey(label: '#', action: ExtraKeyAction.insert, value: '#'),
  ExtraKey(label: '', action: ExtraKeyAction.insert, value: ''),
  ExtraKey(label: '^', action: ExtraKeyAction.insert, value: '^'),
  ExtraKey(label: '-', action: ExtraKeyAction.insert, value: '-'),
];
