import 'package:flutter/material.dart';

// Enum to define what an extra key does
enum ExtraKeyAction {
  insert,      // Inserts text
  command,     // Executes a CodeForgeController method (e.g., 'saveFile', 'duplicateLine')
  modifier,    // Toggles a modifier state (e.g., 'ctrl', 'shift')
  arrow,       // Special arrow key actions
  backspace,   // Backspace action
  delete,      // Delete action
}

// Model for a single extra key button
class ExtraKey {
  final String? label;         // Text on the button (e.g., "{", "Ctrl")
  final IconData? icon;        // Icon on the button (e.g., Icons.arrow_left)
  final ExtraKeyAction action;
  final dynamic value;         // Data for the action (e.g., text to insert, command name, modifier name)

  const ExtraKey({
    this.label,
    this.icon,
    required this.action,
    this.value,
  });

  // Helper to determine if the key has a text label
  bool get hasLabel => label != null && label!.isNotEmpty;
  // Helper to determine if the key has an icon
  bool get hasIcon => icon != null;
}
