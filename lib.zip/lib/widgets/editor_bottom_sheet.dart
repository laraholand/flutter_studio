// import 'package:flutter/material.dart';
// import 'package:flutter_studio/pages/terminal_page.dart';
// import 'package:flutter_studio/services/command_executor_service.dart';
// import 'package:xterm/xterm.dart';

// class EditorBottomSheet extends StatefulWidget {
// final String projectRootDir; // Added type
// const EditorBottomSheet({
// required this.projectRootDir,
// super.key,
// }); // Corrected constructor syntax

// @override
// State<EditorBottomSheet> createState() => _EditorBottomSheetState();
// }

// class _EditorBottomSheetState extends State<EditorBottomSheet> {
// // Declare as late and initialize in initState
// late CommandExecutorService executorService;

// @override
// void initState() {
// super.initState();
// // Initialize CommandExecutorService here, using widget.projectRootDir
// // The factory constructor handles the singleton logic.
// // The command passed here is sent once after connection is established.
// executorService = CommandExecutorService(
// command:
// 'cd ${widget.projectRootDir}', // Ensure it starts in the correct dir
// );
// }

// // Added dispose to clean up if necessary, though CommandExecutorService is a singleton
// @override
// void dispose() {
// // If CommandExecutorService were not a singleton, you'd call executorService.dispose();
// // For a singleton, its lifecycle is usually managed externally or it lives as long as the app.
// super.dispose();
// }

// @override
// Widget build(BuildContext context) {
// return DefaultTabController(
// length: 3,
// child: Column(
// children: [
// // Added const
// const TabBar(
// tabs: [
// Tab(text: "Build outputs"),
// Tab(text: "Pub Commands"),
// Tab(text: "Terminal "),
// ],
// ),
// Expanded(
// child: TabBarView(
// children: [
// // Use the initialized executorService.terminal
// TerminalView(executorService.terminal),
// // Pass projectRootDir to PubCommands (will be modified next)
// PubCommands(projectRootDir: widget.projectRootDir),
// TerminalPage(),
// ],
// ),
// ),
// ],
// ),
// );
// }
// }

// class PubCommands extends StatefulWidget {
// // Added projectRootDir parameter and type
// final String projectRootDir;
// const PubCommands({required this.projectRootDir, super.key});

// @override
// State<PubCommands> createState() => _PubCommandsState();
// }

// class _PubCommandsState extends State<PubCommands> {
// // Declare as late, will be initialized in initState
// late CommandExecutorService commandExecutorService;

// @override
// void initState() {
// super.initState();
// // Get the singleton instance using the factory constructor.
// // This ensures we use the same terminal session initialized by EditorBottomSheet.
// commandExecutorService = CommandExecutorService(command: '\n');
// }

// @override
// Widget build(BuildContext context) {
// return Column(
// children: [
// Wrap(
// children: [
// OutlinedButton(
// onPressed: () {
// // Ensure execution in the correct project directory
// commandExecutorService.sendCommand(
// 'cd ${widget.projectRootDir}\n',
// );
// commandExecutorService.sendCommand('pub get\n');
// },
// child: const Text('pub get'), // Added const
// ),
// OutlinedButton(
// onPressed: () {
// commandExecutorService.sendCommand(
// 'cd ${widget.projectRootDir}\n',
// );
// commandExecutorService.sendCommand(
// 'pub add\n',
// ); // Note: 'pub add' typically requires an argument.
// },
// child: const Text("pub add"), // Added const
// ),
// OutlinedButton(
// onPressed: () {
// commandExecutorService.sendCommand(
// 'cd ${widget.projectRootDir}\n',
// );
// commandExecutorService.sendCommand('pub upgrade\n');
// },
// child: const Text("pub upgrade"), // Added const
// ),
// OutlinedButton(
// onPressed: () {
// commandExecutorService.sendCommand(
// 'cd ${widget.projectRootDir}\n',
// );
// commandExecutorService.sendCommand('pub search\n');
// },
// child: const Text("pub search"), // Added const
// ),
// OutlinedButton(
// onPressed: () {
// commandExecutorService.sendCommand(
// 'cd ${widget.projectRootDir}\n',
// );
// commandExecutorService.sendCommand('pub outdated\n');
// },
// child: const Text("pub outdated"), // Added const
// ),
// ],
// ),
// Expanded(
// // Use the singleton instance's terminal. Output will be shared with 'Build outputs' tab.
// child: TerminalView(commandExecutorService.terminal),
// ),
// ],
// );
// }
// }
