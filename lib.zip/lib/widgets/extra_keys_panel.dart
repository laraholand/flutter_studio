import 'package:flutter/material.dart';
import 'package:flutter_studio/code_forge.dart';
import 'package:flutter_studio/util/extra_key_data.dart';
import 'package:flutter_studio/util/extra_key_model.dart';

class ExtraKeysPanel extends StatefulWidget {
  final CodeForgeController? controller;

  const ExtraKeysPanel({super.key, this.controller});

  @override
  State<ExtraKeysPanel> createState() => _ExtraKeysPanelState();
}

class _ExtraKeysPanelState extends State<ExtraKeysPanel> {
  final Map<String, bool> _modifierState = {
    'ctrl': false,
    'shift': false,
    'alt': false,
  };

  void _handleKeyPress(ExtraKey key) {
    if (widget.controller == null) return;

    final controller = widget.controller!;
    final bool isShiftPressed = _modifierState['shift']!;
    final bool isCtrlPressed = _modifierState['ctrl']!;
    final bool isAltPressed = _modifierState['alt']!;

    // Handle modifier keys
    if (key.action == ExtraKeyAction.modifier) {
      setState(() {
        _modifierState[key.value as String] = !_modifierState[key.value as String]!;
      });
      return; // Modifier keys only toggle their state
    }

    // Handle other actions
    switch (key.action) {
      case ExtraKeyAction.insert:
        controller.insertAtCurrentCursor(key.value as String);
        break;
      case ExtraKeyAction.command:
        _executeCommand(key.value as String, controller);
        break;
      case ExtraKeyAction.arrow:
        _handleArrowKey(key.value as String, controller, isShiftPressed, isCtrlPressed, isAltPressed);
        break;
      case ExtraKeyAction.backspace:
        controller.backspace();
        break;
      case ExtraKeyAction.delete:
        controller.delete();
        break;
      case ExtraKeyAction.modifier:
        // This case is handled at the beginning of the function
        break;
    }

    // Reset modifier states after any non-modifier key is pressed
    setState(() {
      _modifierState.updateAll((key, value) => false);
    });
  }

  void _executeCommand(String command, CodeForgeController controller) {
    switch (command) {
      case 'getCodeAction':
        controller.getCodeAction();
        break;
      case 'callSignatureHelp':
        controller.callSignatureHelp();
        break;
      case 'duplicateLine':
        controller.duplicateLine();
        break;
      case 'dismissSuggestions':
        controller.dismissLspFeatures();
        break;
      // Add other custom commands here
    }
  }

  void _handleArrowKey(
    String direction,
    CodeForgeController controller,
    bool isShiftPressed,
    bool isCtrlPressed,
    bool isAltPressed,
  ) {
    switch (direction) {
      case 'left':
        controller.pressLetfArrowKey(isShiftPressed: isShiftPressed, isCtrlPressed: isCtrlPressed, isAltPressed: isAltPressed);
        break;
      case 'right':
        controller.pressRightArrowKey(isShiftPressed: isShiftPressed, isCtrlPressed: isCtrlPressed, isAltPressed: isAltPressed);
        break;
      case 'up':
        controller.pressUpArrowKey(isShiftPressed: isShiftPressed, isCtrlPressed: isCtrlPressed, isAltPressed: isAltPressed);
        break;
      case 'down':
        controller.pressDownArrowKey(isShiftPressed: isShiftPressed, isCtrlPressed: isCtrlPressed, isAltPressed: isAltPressed);
        break;
      case 'home': // Assuming Home/End keys might also use this handler
        controller.pressHomeKey(isShiftPressed: isShiftPressed, isCtrlPressed: isCtrlPressed, isAltPressed: isAltPressed);
        break;
      case 'end': // Assuming Home/End keys might also use this handler
        controller.pressEndKey(isShiftPressed: isShiftPressed, isCtrlPressed: isCtrlPressed, isAltPressed: isAltPressed);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.controller == null) {
      return const SizedBox.shrink();
    }
    final ColorScheme colorScheme = Theme.of(context).colorScheme;

    return Container(
      color: colorScheme.surface,
      child: Column(
        children: [
          _buildKeyRow(extraKeysRow1Data, colorScheme),
          _buildKeyRow(extraKeysRow2Data, colorScheme),
        ],
      ),
    );
  }

  Widget _buildKeyRow(List<ExtraKey> keys, ColorScheme colorScheme) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: keys.map((key) {
          final bool isModifierActive = key.action == ExtraKeyAction.modifier && _modifierState[key.value as String]!;

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: isModifierActive ? colorScheme.primary : colorScheme.surface,
                foregroundColor: isModifierActive ? colorScheme.onPrimary : colorScheme.onSurface,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                  side: BorderSide(color: colorScheme.onPrimary, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                minimumSize: Size.zero, // Remove default minimum size constraint
                tapTargetSize: MaterialTapTargetSize.shrinkWrap, // Shrink wrap tap target
              ),
              onPressed: () => _handleKeyPress(key),
              child: key.hasLabel
                  ? Text(
                      key.label!,
                      style: TextStyle(
                        color: isModifierActive ? colorScheme.onPrimary : colorScheme.onSurface,
                      ),
                    )
                  : Icon(
                      key.icon!,
                      size: 18,
                      color: isModifierActive ? colorScheme.onPrimary : colorScheme.onSurface,
                    ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
